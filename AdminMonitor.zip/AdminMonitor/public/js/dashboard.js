class DashboardManager {
  constructor() {
    this.socket = null;
    this.webrtc = null;
    this.devices = new Map();
    this.selectedDevice = null;
    this.isConnected = false;
    
    this.initializeElements();
    this.initializeEventListeners();
  }
  
  initializeElements() {
    // Connection elements
    this.connectionStatus = document.getElementById('connectionStatus');
    
    // Device elements
    this.devicesList = document.getElementById('devicesList');
    this.deviceCount = document.getElementById('deviceCount');
    
    // Control elements
    this.requestStreamBtn = document.getElementById('requestStreamBtn');
    this.stopStreamBtn = document.getElementById('stopStreamBtn');
    
    // Log elements
    this.logContainer = document.getElementById('logContainer');
    this.logLevel = document.getElementById('logLevel');
    this.clearLogsBtn = document.getElementById('clearLogsBtn');
    
    this.logs = [];
  }
  
  initializeEventListeners() {
    // Stream control buttons
    this.requestStreamBtn.addEventListener('click', () => {
      if (this.selectedDevice) {
        this.requestStream(this.selectedDevice);
      }
    });
    
    this.stopStreamBtn.addEventListener('click', () => {
      this.stopStream();
    });
    
    // Log controls
    this.logLevel.addEventListener('change', () => {
      this.filterLogs();
    });
    
    this.clearLogsBtn.addEventListener('click', () => {
      this.clearLogs();
    });
  }
  
  initialize(socket, webrtc) {
    this.socket = socket;
    this.webrtc = webrtc;
    
    this.setupSocketListeners();
    this.webrtc.startHealthCheck();
  }
  
  setupSocketListeners() {
    if (!this.socket) return;
    
    // Connection events
    this.socket.on('connect', () => {
      this.updateConnectionStatus('connected');
      this.addLog('Connected to server', 'success');
    });
    
    this.socket.on('disconnect', () => {
      this.updateConnectionStatus('disconnected');
      this.addLog('Disconnected from server', 'error');
      this.clearDevices();
    });
    
    this.socket.on('connect_error', (error) => {
      this.addLog(`Connection error: ${error.message}`, 'error');
    });
    
    // Authentication events
    this.socket.on('auth-success', (data) => {
      this.addLog(`Authenticated as ${data.user.email}`, 'success');
    });
    
    this.socket.on('auth-error', (data) => {
      this.addLog(`Authentication failed: ${data.error}`, 'error');
    });
    
    // Device events
    this.socket.on('device-online', (device) => {
      this.addDevice(device);
      this.addLog(`Device connected: ${device.deviceName || device.deviceId}`, 'info');
    });
    
    this.socket.on('device-offline', (data) => {
      this.removeDevice(data.deviceId);
      this.addLog(`Device disconnected: ${data.deviceId}`, 'warning');
    });
    
    this.socket.on('device-joined', (data) => {
      this.updateDeviceStatus(data.deviceId, 'online');
      this.addLog(`Device joined room: ${data.deviceName || data.deviceId}`, 'info');
    });
    
    this.socket.on('device-left', (data) => {
      this.updateDeviceStatus(data.deviceId, 'offline');
    });
    
    this.socket.on('device-streaming-started', (data) => {
      this.updateDeviceStatus(data.deviceId, 'streaming');
      this.addLog(`Device started streaming: ${data.deviceName}`, 'success');
    });
    
    this.socket.on('device-streaming-stopped', (data) => {
      this.updateDeviceStatus(data.deviceId, 'online');
      this.addLog(`Device stopped streaming: ${data.deviceName}`, 'info');
    });
    
    // WebRTC signaling events
    this.socket.on('offer', (data) => {
      this.addLog(`Received offer from ${data.from}`, 'info');
      this.webrtc.handleOffer(data.offer, data.from);
    });
    
    this.socket.on('answer', (data) => {
      this.addLog(`Received answer from ${data.from}`, 'info');
      this.webrtc.handleAnswer(data.answer);
    });
    
    this.socket.on('ice-candidate', (data) => {
      this.webrtc.handleIceCandidate(data.candidate);
    });
    
    // Room events
    this.socket.on('room-status', (status) => {
      this.updateRoomStatus(status);
    });
    
    // Error events
    this.socket.on('error', (data) => {
      this.addLog(`Server error: ${data.message}`, 'error');
    });
  }
  
  updateConnectionStatus(status) {
    this.isConnected = status === 'connected';
    this.connectionStatus.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    this.connectionStatus.className = `connection-status ${status}`;
  }
  
  async loadDevices() {
    try {
      const response = await fetch('/api/devices');
      const devices = await response.json();
      
      this.clearDevices();
      devices.forEach(device => this.addDevice(device));
      
      this.addLog(`Loaded ${devices.length} devices`, 'info');
      
    } catch (error) {
      this.addLog(`Failed to load devices: ${error.message}`, 'error');
    }
  }
  
  addDevice(device) {
    this.devices.set(device.deviceId, device);
    this.renderDevicesList();
  }
  
  removeDevice(deviceId) {
    this.devices.delete(deviceId);
    
    // If this was the selected device, deselect it
    if (this.selectedDevice === deviceId) {
      this.selectDevice(null);
    }
    
    this.renderDevicesList();
  }
  
  updateDeviceStatus(deviceId, status) {
    const device = this.devices.get(deviceId);
    if (device) {
      device.status = status;
      device.lastSeen = new Date().toISOString();
      this.renderDevicesList();
    }
  }
  
  clearDevices() {
    this.devices.clear();
    this.selectDevice(null);
    this.renderDevicesList();
  }
  
  renderDevicesList() {
    const devicesArray = Array.from(this.devices.values());
    this.deviceCount.textContent = `${devicesArray.length} device${devicesArray.length !== 1 ? 's' : ''}`;
    
    if (devicesArray.length === 0) {
      this.devicesList.innerHTML = `
        <div class="no-devices">
          <p>No devices connected</p>
          <p>Devices will appear here when they come online</p>
        </div>
      `;
      return;
    }
    
    this.devicesList.innerHTML = devicesArray.map(device => `
      <div class="device-item ${this.selectedDevice === device.deviceId ? 'selected' : ''}" 
           data-device-id="${device.deviceId}">
        <div class="device-info">
          <h3>${device.deviceName || device.deviceId}</h3>
          <p>ID: ${device.deviceId}</p>
          <p>Last seen: ${this.formatTime(device.lastSeen)}</p>
        </div>
        <div class="device-status ${device.status || 'offline'}">
          ${device.status || 'offline'}
        </div>
      </div>
    `).join('');
    
    // Add click listeners to device items
    this.devicesList.querySelectorAll('.device-item').forEach(item => {
      item.addEventListener('click', () => {
        const deviceId = item.dataset.deviceId;
        this.selectDevice(deviceId);
      });
    });
  }
  
  selectDevice(deviceId) {
    this.selectedDevice = deviceId;
    
    // Update UI
    this.renderDevicesList();
    
    if (deviceId) {
      const device = this.devices.get(deviceId);
      this.requestStreamBtn.disabled = false;
      this.requestStreamBtn.textContent = `Connect to ${device?.deviceName || deviceId}`;
    } else {
      this.requestStreamBtn.disabled = true;
      this.requestStreamBtn.textContent = 'Select a device';
    }
  }
  
  requestStream(deviceId) {
    const device = this.devices.get(deviceId);
    if (!device) {
      this.addLog(`Device not found: ${deviceId}`, 'error');
      return;
    }
    
    this.addLog(`Requesting stream from ${device.deviceName || deviceId}`, 'info');
    
    // Update UI
    this.requestStreamBtn.disabled = true;
    this.stopStreamBtn.disabled = false;
    
    // Request stream via WebRTC
    this.webrtc.requestStream(deviceId);
  }
  
  stopStream() {
    this.addLog('Stopping stream', 'info');
    
    // Update UI
    this.requestStreamBtn.disabled = false;
    this.stopStreamBtn.disabled = true;
    
    // Stop WebRTC stream
    this.webrtc.stopStream();
  }
  
  // WebRTC helper methods
  requestDeviceStream(deviceId) {
    if (this.socket) {
      this.socket.emit('request-stream', { deviceId });
    }
  }
  
  sendAnswer(answer, targetId) {
    if (this.socket) {
      this.socket.emit('answer', {
        answer: answer,
        targetId: targetId,
        roomId: `room_${this.selectedDevice}`
      });
    }
  }
  
  sendIceCandidate(candidate) {
    if (this.socket) {
      this.socket.emit('ice-candidate', {
        candidate: {
          candidate: candidate.candidate,
          sdpMLineIndex: candidate.sdpMLineIndex,
          sdpMid: candidate.sdpMid
        },
        roomId: `room_${this.selectedDevice}`
      });
    }
  }
  
  notifyStreamStopped() {
    // Notify server that we stopped receiving stream
    this.addLog('Stream connection closed', 'info');
  }
  
  updateRoomStatus(status) {
    this.addLog(`Room status: ${status.devices.length} devices, ${status.adminCount} admins`, 'info');
  }
  
  // Logging methods
  addLog(message, level = 'info') {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = {
      timestamp,
      message,
      level,
      id: Date.now() + Math.random()
    };
    
    this.logs.unshift(logEntry); // Add to beginning
    
    // Keep only last 100 logs
    if (this.logs.length > 100) {
      this.logs = this.logs.slice(0, 100);
    }
    
    this.renderLogs();
    console.log(`[${level.toUpperCase()}] ${message}`);
  }
  
  renderLogs() {
    const filteredLogs = this.filterLogsByLevel();
    
    this.logContainer.innerHTML = filteredLogs.map(log => `
      <div class="log-entry ${log.level}">
        [${log.timestamp}] ${log.message}
      </div>
    `).join('');
    
    // Auto-scroll to top (newest logs)
    this.logContainer.scrollTop = 0;
  }
  
  filterLogs() {
    this.renderLogs();
  }
  
  filterLogsByLevel() {
    const selectedLevel = this.logLevel.value;
    
    if (selectedLevel === 'all') {
      return this.logs;
    }
    
    return this.logs.filter(log => log.level === selectedLevel);
  }
  
  clearLogs() {
    this.logs = [];
    this.renderLogs();
    this.addLog('Logs cleared', 'info');
  }
  
  // Utility methods
  formatTime(timestamp) {
    if (!timestamp) return 'Never';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) { // Less than 1 minute
      return 'Just now';
    } else if (diff < 3600000) { // Less than 1 hour
      const minutes = Math.floor(diff / 60000);
      return `${minutes}m ago`;
    } else if (diff < 86400000) { // Less than 1 day
      const hours = Math.floor(diff / 3600000);
      return `${hours}h ago`;
    } else {
      return date.toLocaleDateString();
    }
  }
  
  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
    }
    
    if (this.webrtc) {
      this.webrtc.cleanup();
    }
    
    this.clearDevices();
    this.addLog('Disconnected', 'warning');
  }
}

// Export for global use
window.DashboardManager = DashboardManager;