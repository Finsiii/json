class AuthManager {
  constructor() {
    this.auth = window.FirebaseAuth;
    this.currentUser = null;
    this.socket = null;
    
    this.initializeAuth();
  }
  
  initializeAuth() {
    // Listen for auth state changes
    this.auth.onAuthStateChanged((user) => {
      if (user) {
        this.handleAuthSuccess(user);
      } else {
        this.handleAuthFailure();
      }
    });
    
    // Setup Email Sign In
    this.setupEmailSignIn();
  }
  
  setupEmailSignIn() {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('emailInput');
    const passwordInput = document.getElementById('passwordInput');
    const signInBtn = document.getElementById('signInBtn');
    const toggleModeBtn = document.getElementById('toggleModeBtn');
    const formTitle = document.getElementById('formTitle');
    
    let isSignUpMode = false;
    
    // Toggle between sign in and sign up
    toggleModeBtn.addEventListener('click', () => {
      isSignUpMode = !isSignUpMode;
      if (isSignUpMode) {
        formTitle.textContent = 'Create Admin Account';
        signInBtn.textContent = 'Sign Up';
        toggleModeBtn.textContent = 'Already have an account? Sign In';
      } else {
        formTitle.textContent = 'Admin Sign In';
        signInBtn.textContent = 'Sign In';
        toggleModeBtn.textContent = "Don't have an account? Sign Up";
      }
    });
    
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const email = emailInput.value.trim();
      const password = passwordInput.value;
      
      if (!email || !password) {
        this.showError('Please fill in all fields');
        return;
      }
      
      try {
        signInBtn.disabled = true;
        signInBtn.innerHTML = '<div class="spinner"></div> Processing...';
        
        if (isSignUpMode) {
          await this.signUpWithEmail(email, password);
        } else {
          await this.signInWithEmail(email, password);
        }
        
      } catch (error) {
        console.error('Authentication failed:', error);
        this.showError(this.getErrorMessage(error));
        
      } finally {
        signInBtn.disabled = false;
        signInBtn.textContent = isSignUpMode ? 'Sign Up' : 'Sign In';
      }
    });
    
    // Setup logout
    const logoutBtn = document.getElementById('logoutBtn');
    logoutBtn.addEventListener('click', () => {
      this.signOut();
    });
  }
  
  async signInWithEmail(email, password) {
    const result = await this.auth.signInWithEmailAndPassword(email, password);
    return result.user;
  }
  
  async signUpWithEmail(email, password) {
    // Create user account
    const result = await this.auth.createUserWithEmailAndPassword(email, password);
    
    // Create admin record in Firestore
    await this.createAdminRecord(result.user);
    
    return result.user;
  }
  
  async createAdminRecord(user) {
    try {
      // This will be handled by the server when the user authenticates
      // We'll send the user info to create admin record
      const idToken = await user.getIdToken();
      
      const response = await fetch('/api/admin/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${idToken}`
        },
        body: JSON.stringify({
          email: user.email,
          uid: user.uid,
          role: 'admin'
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to create admin record');
      }
      
    } catch (error) {
      console.error('Failed to create admin record:', error);
      // Don't throw error here, let sign up succeed even if admin record creation fails
    }
  }
  
  getErrorMessage(error) {
    switch (error.code) {
      case 'auth/user-not-found':
        return 'No account found with this email address';
      case 'auth/wrong-password':
        return 'Incorrect password';
      case 'auth/email-already-in-use':
        return 'An account with this email already exists';
      case 'auth/weak-password':
        return 'Password should be at least 6 characters';
      case 'auth/invalid-email':
        return 'Please enter a valid email address';
      case 'auth/too-many-requests':
        return 'Too many failed attempts. Please try again later';
      default:
        return error.message || 'Authentication failed';
    }
  }
  
  async handleAuthSuccess(user) {
    try {
      this.currentUser = user;
      
      // Get ID token for server authentication
      const idToken = await user.getIdToken();
      
      // Update UI
      this.updateUserUI(user);
      
      // Authenticate with server
      await this.authenticateWithServer(idToken);
      
      // Show main dashboard
      this.showDashboard();
      
    } catch (error) {
      console.error('Auth success handling failed:', error);
      this.showError('Authentication failed. Please try again.');
    }
  }
  
  handleAuthFailure() {
    this.currentUser = null;
    this.showLogin();
  }
  
  async authenticateWithServer(idToken) {
    // This will be handled via Socket.IO
    if (window.dashboardManager && window.dashboardManager.socket) {
      window.dashboardManager.socket.emit('admin-auth', { idToken });
    }
  }
  
  updateUserUI(user) {
    const adminName = document.getElementById('adminName');
    const adminAvatar = document.getElementById('adminAvatar');
    
    adminName.textContent = user.displayName || user.email;
    adminAvatar.src = user.photoURL || '/images/default-avatar.png';
  }
  
  async signOut() {
    try {
      // Disconnect from server
      if (window.dashboardManager) {
        window.dashboardManager.disconnect();
      }
      
      await this.auth.signOut();
      this.showLogin();
      
    } catch (error) {
      console.error('Sign out failed:', error);
    }
  }
  
  showLogin() {
    document.getElementById('loadingScreen').classList.add('hidden');
    document.getElementById('loginScreen').classList.remove('hidden');
    document.getElementById('mainDashboard').classList.add('hidden');
  }
  
  showDashboard() {
    document.getElementById('loadingScreen').classList.add('hidden');
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('mainDashboard').classList.remove('hidden');
  }
  
  showLoading() {
    document.getElementById('loadingScreen').classList.remove('hidden');
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('mainDashboard').classList.add('hidden');
  }
  
  showError(message) {
    // Simple error display - you can enhance this
    alert(message);
  }
  
  getCurrentUser() {
    return this.currentUser;
  }
  
  async getCurrentIdToken() {
    if (this.currentUser) {
      return await this.currentUser.getIdToken();
    }
    return null;
  }
}

// Export for global use
window.AuthManager = AuthManager;