const Logger = require('../utils/Logger');

class WebRTCSignaling {
  constructor(io, deviceManager) {
    this.io = io;
    this.deviceManager = deviceManager;
    this.logger = new Logger();
    this.activeRooms = new Map(); // roomId -> { devices: Set, admins: Set }
  }
  
  handleConnection(socket) {
    // Join room
    socket.on('join-room', (roomId) => {
      this.joinRoom(socket, roomId);
    });
    
    // Leave room
    socket.on('leave-room', (roomId) => {
      this.leaveRoom(socket, roomId);
    });
    
    // WebRTC signaling messages
    socket.on('offer', (data) => {
      this.handleOffer(socket, data);
    });
    
    socket.on('answer', (data) => {
      this.handleAnswer(socket, data);
    });
    
    socket.on('ice-candidate', (data) => {
      this.handleIceCandidate(socket, data);
    });
    
    // Request stream from specific device
    socket.on('request-stream', (data) => {
      this.requestStream(socket, data);
    });
    
    // Device streaming status
    socket.on('streaming-started', (data) => {
      this.handleStreamingStarted(socket, data);
    });
    
    socket.on('streaming-stopped', (data) => {
      this.handleStreamingStopped(socket, data);
    });
    
    // Handle socket disconnect
    socket.on('disconnect', () => {
      this.handleDisconnect(socket);
    });
  }
  
  joinRoom(socket, roomId) {
    try {
      socket.join(roomId);
      
      // Initialize room if it doesn't exist
      if (!this.activeRooms.has(roomId)) {
        this.activeRooms.set(roomId, {
          devices: new Set(),
          admins: new Set()
        });
      }
      
      const room = this.activeRooms.get(roomId);
      const deviceInfo = this.deviceManager.getDeviceBySocketId(socket.id);
      
      if (deviceInfo) {
        // This is a device joining
        room.devices.add(socket.id);
        socket.deviceRoom = roomId;
        
        // Notify admins about device joining
        socket.to(roomId).emit('device-joined', {
          deviceId: deviceInfo.deviceId,
          deviceName: deviceInfo.deviceName,
          socketId: socket.id
        });
        
        this.logger.info(`Device ${deviceInfo.deviceId} joined room: ${roomId}`);
        
      } else if (socket.adminUser) {
        // This is an admin joining
        room.admins.add(socket.id);
        socket.adminRoom = roomId;
        
        // Send current room status to admin
        const roomStatus = this.getRoomStatus(roomId);
        socket.emit('room-status', roomStatus);
        
        // Notify devices about admin joining
        socket.to(roomId).emit('admin-joined', {
          adminId: socket.adminUser.uid,
          adminEmail: socket.adminUser.email
        });
        
        this.logger.info(`Admin ${socket.adminUser.email} joined room: ${roomId}`);
      }
      
    } catch (error) {
      this.logger.error('Failed to join room:', error);
      socket.emit('error', { message: 'Failed to join room' });
    }
  }
  
  leaveRoom(socket, roomId) {
    try {
      socket.leave(roomId);
      
      if (this.activeRooms.has(roomId)) {
        const room = this.activeRooms.get(roomId);
        room.devices.delete(socket.id);
        room.admins.delete(socket.id);
        
        // Clean up empty room
        if (room.devices.size === 0 && room.admins.size === 0) {
          this.activeRooms.delete(roomId);
        }
      }
      
      // Notify others in room
      const deviceInfo = this.deviceManager.getDeviceBySocketId(socket.id);
      if (deviceInfo) {
        socket.to(roomId).emit('device-left', { deviceId: deviceInfo.deviceId });
      } else if (socket.adminUser) {
        socket.to(roomId).emit('admin-left', { adminId: socket.adminUser.uid });
      }
      
      this.logger.info(`Socket ${socket.id} left room: ${roomId}`);
      
    } catch (error) {
      this.logger.error('Failed to leave room:', error);
    }
  }
  
  handleOffer(socket, data) {
    try {
      const { roomId, offer, targetId } = data;
      
      if (targetId) {
        // Send to specific target
        socket.to(targetId).emit('offer', {
          offer: offer,
          from: socket.id,
          roomId: roomId
        });
      } else {
        // Broadcast to room
        socket.to(roomId).emit('offer', {
          offer: offer,
          from: socket.id,
          roomId: roomId
        });
      }
      
      this.logger.info(`Offer sent from ${socket.id} to room ${roomId}`);
      
    } catch (error) {
      this.logger.error('Failed to handle offer:', error);
    }
  }
  
  handleAnswer(socket, data) {
    try {
      const { roomId, answer, targetId } = data;
      
      if (targetId) {
        socket.to(targetId).emit('answer', {
          answer: answer,
          from: socket.id,
          roomId: roomId
        });
      } else {
        socket.to(roomId).emit('answer', {
          answer: answer,
          from: socket.id,
          roomId: roomId
        });
      }
      
      this.logger.info(`Answer sent from ${socket.id} to room ${roomId}`);
      
    } catch (error) {
      this.logger.error('Failed to handle answer:', error);
    }
  }
  
  handleIceCandidate(socket, data) {
    try {
      const { roomId, candidate, targetId } = data;
      
      if (targetId) {
        socket.to(targetId).emit('ice-candidate', {
          candidate: candidate,
          from: socket.id,
          roomId: roomId
        });
      } else {
        socket.to(roomId).emit('ice-candidate', {
          candidate: candidate,
          from: socket.id,
          roomId: roomId
        });
      }
      
    } catch (error) {
      this.logger.error('Failed to handle ICE candidate:', error);
    }
  }
  
  requestStream(socket, data) {
    try {
      const { deviceId } = data;
      const deviceSocketId = this.deviceManager.getSocketIdByDeviceId(deviceId);
      
      if (deviceSocketId) {
        // Send stream request to device
        socket.to(deviceSocketId).emit('stream-request', {
          from: socket.id,
          adminId: socket.adminUser?.uid
        });
        
        this.logger.info(`Stream requested from device ${deviceId} by admin ${socket.adminUser?.email}`);
      } else {
        socket.emit('error', { message: 'Device not found or offline' });
      }
      
    } catch (error) {
      this.logger.error('Failed to request stream:', error);
    }
  }
  
  async handleStreamingStarted(socket, data) {
    try {
      const deviceInfo = this.deviceManager.getDeviceBySocketId(socket.id);
      
      if (deviceInfo) {
        await this.deviceManager.setDeviceStreaming(deviceInfo.deviceId, true);
        
        // Notify admins in the same room
        if (socket.deviceRoom) {
          socket.to(socket.deviceRoom).emit('device-streaming-started', {
            deviceId: deviceInfo.deviceId,
            deviceName: deviceInfo.deviceName
          });
        }
        
        this.logger.info(`Device ${deviceInfo.deviceId} started streaming`);
      }
      
    } catch (error) {
      this.logger.error('Failed to handle streaming started:', error);
    }
  }
  
  async handleStreamingStopped(socket, data) {
    try {
      const deviceInfo = this.deviceManager.getDeviceBySocketId(socket.id);
      
      if (deviceInfo) {
        await this.deviceManager.setDeviceStreaming(deviceInfo.deviceId, false);
        
        // Notify admins in the same room
        if (socket.deviceRoom) {
          socket.to(socket.deviceRoom).emit('device-streaming-stopped', {
            deviceId: deviceInfo.deviceId,
            deviceName: deviceInfo.deviceName
          });
        }
        
        this.logger.info(`Device ${deviceInfo.deviceId} stopped streaming`);
      }
      
    } catch (error) {
      this.logger.error('Failed to handle streaming stopped:', error);
    }
  }
  
  handleDisconnect(socket) {
    try {
      // Clean up room membership
      if (socket.deviceRoom) {
        this.leaveRoom(socket, socket.deviceRoom);
      }
      
      if (socket.adminRoom) {
        this.leaveRoom(socket, socket.adminRoom);
      }
      
    } catch (error) {
      this.logger.error('Failed to handle disconnect cleanup:', error);
    }
  }
  
  getRoomStatus(roomId) {
    if (!this.activeRooms.has(roomId)) {
      return { devices: [], admins: [], isEmpty: true };
    }
    
    const room = this.activeRooms.get(roomId);
    
    const devices = Array.from(room.devices).map(socketId => {
      const deviceInfo = this.deviceManager.getDeviceBySocketId(socketId);
      return deviceInfo ? {
        deviceId: deviceInfo.deviceId,
        deviceName: deviceInfo.deviceName,
        status: deviceInfo.status,
        socketId: socketId
      } : null;
    }).filter(Boolean);
    
    return {
      devices: devices,
      adminCount: room.admins.size,
      isEmpty: devices.length === 0 && room.admins.size === 0
    };
  }
  
  getActiveRoomsCount() {
    return this.activeRooms.size;
  }
}

module.exports = WebRTCSignaling;