const admin = require('firebase-admin');
const path = require('path');
const fs = require('fs');
const Logger = require('../utils/Logger');

class FirebaseService {
  constructor() {
    this.logger = new Logger();
    this.initializeFirebase();
  }
  
  initializeFirebase() {
    try {
      // Initialize Firebase Admin SDK
      if (!admin.apps.length) {
        // Try to use service account file first
        const serviceAccountPath = path.join(__dirname, '../../config/serviceAccountKey.json');
        
        if (fs.existsSync(serviceAccountPath)) {
          admin.initializeApp({
            credential: admin.credential.cert(serviceAccountPath),
            databaseURL: `https://${process.env.FIREBASE_PROJECT_ID || 'ikky-b414a'}-default-rtdb.firebaseio.com`
          });
        } else {
          // Fallback to environment variables
          admin.initializeApp({
            credential: admin.credential.cert({
              projectId: process.env.FIREBASE_PROJECT_ID,
              clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
              privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n')
            }),
            databaseURL: `https://${process.env.FIREBASE_PROJECT_ID}-default-rtdb.firebaseio.com`
          });
        }
      }
      
      this.db = admin.firestore();
      this.auth = admin.auth();
      this.logger.info('Firebase initialized successfully');
      
    } catch (error) {
      this.logger.error('Firebase initialization failed:', error);
      throw error;
    }
  }
  
  async verifyAdminToken(idToken) {
    try {
      const decodedToken = await this.auth.verifyIdToken(idToken);
      
      // Check if user is admin
      const userDoc = await this.db.collection('admins').doc(decodedToken.uid).get();
      
      if (!userDoc.exists) {
        throw new Error('User is not an admin');
      }
      
      const adminData = userDoc.data();
      return {
        uid: decodedToken.uid,
        email: decodedToken.email,
        role: adminData.role || 'admin',
        permissions: adminData.permissions || []
      };
      
    } catch (error) {
      this.logger.error('Token verification failed:', error);
      throw error;
    }
  }
  
  async saveDevice(deviceData) {
    try {
      const deviceRef = this.db.collection('devices').doc(deviceData.deviceId);
      await deviceRef.set({
        ...deviceData,
        lastUpdated: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
      
      this.logger.info(`Device saved: ${deviceData.deviceId}`);
      return deviceData;
      
    } catch (error) {
      this.logger.error('Failed to save device:', error);
      throw error;
    }
  }
  
  async getDevice(deviceId) {
    try {
      const deviceDoc = await this.db.collection('devices').doc(deviceId).get();
      
      if (!deviceDoc.exists) {
        return null;
      }
      
      return {
        id: deviceDoc.id,
        ...deviceDoc.data()
      };
      
    } catch (error) {
      this.logger.error('Failed to get device:', error);
      throw error;
    }
  }
  
  async getAllDevices() {
    try {
      const devicesSnapshot = await this.db.collection('devices').get();
      
      const devices = [];
      devicesSnapshot.forEach(doc => {
        devices.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      return devices;
      
    } catch (error) {
      this.logger.error('Failed to get all devices:', error);
      throw error;
    }
  }
  
  async updateDeviceStatus(deviceId, status) {
    try {
      const deviceRef = this.db.collection('devices').doc(deviceId);
      await deviceRef.update({
        status: status,
        lastSeen: admin.firestore.FieldValue.serverTimestamp()
      });
      
      this.logger.info(`Device status updated: ${deviceId} - ${status}`);
      
    } catch (error) {
      this.logger.error('Failed to update device status:', error);
      throw error;
    }
  }
  
  async logActivity(deviceId, activity) {
    try {
      await this.db.collection('activity_logs').add({
        deviceId: deviceId,
        activity: activity,
        timestamp: admin.firestore.FieldValue.serverTimestamp()
      });
      
    } catch (error) {
      this.logger.error('Failed to log activity:', error);
    }
  }
  
  async getActivityLogs(deviceId, limit = 50) {
    try {
      const logsSnapshot = await this.db
        .collection('activity_logs')
        .where('deviceId', '==', deviceId)
        .orderBy('timestamp', 'desc')
        .limit(limit)
        .get();
      
      const logs = [];
      logsSnapshot.forEach(doc => {
        logs.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      return logs;
      
    } catch (error) {
      this.logger.error('Failed to get activity logs:', error);
      throw error;
    }
  }
  
  async createAdminRecord(adminData) {
    try {
      const adminRef = this.db.collection('admins').doc(adminData.uid);
      await adminRef.set(adminData, { merge: true });
      
      this.logger.info(`Admin record created: ${adminData.email}`);
      return adminData;
      
    } catch (error) {
      this.logger.error('Failed to create admin record:', error);
      throw error;
    }
  }
}

module.exports = FirebaseService;