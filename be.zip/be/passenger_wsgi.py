# passenger_wsgi.py
import sys
import os

# Menambahkan direktori aplikasi ke sys.path
sys.path.insert(0, os.path.dirname(__file__))

# Impor aplikasi Flask dari app.py
from app import app as application