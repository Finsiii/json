// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyAebib5rmB-5EqnJLv3KFD1U9rHy-Elyx8",
  authDomain: "ikky-b414a.firebaseapp.com",
  projectId: "ikky-b414a",
  storageBucket: "ikky-b414a.firebasestorage.app",
  messagingSenderId: "35128247892",
  appId: "1:35128247892:android:ab41e30b74abde2dbc4fc1",
  databaseURL: "https://ikky-b414a-default-rtdb.firebaseio.com"
};

// App Configuration
const appConfig = {
  serverUrl: window.location.origin,
  websocketUrl: window.location.origin,
  webrtc: {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:34.143.198.169:3478' }
    ]
  },
  video: {
    constraints: {
      video: false, // Admin doesn't send video
      audio: false  // Admin doesn't send audio
    }
  }
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Export for use in other modules
window.AppConfig = appConfig;
window.FirebaseAuth = firebase.auth();