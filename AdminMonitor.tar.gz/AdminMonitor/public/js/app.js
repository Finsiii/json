// Main Application Entry Point
class ChildMonitorApp {
  constructor() {
    this.authManager = null;
    this.dashboardManager = null;
    this.webrtcManager = null;
    this.socket = null;
    
    this.initialize();
  }
  
  async initialize() {
    try {
      // Show loading screen
      this.showLoading();
      
      // Initialize managers
      this.authManager = new window.AuthManager();
      this.dashboardManager = new window.DashboardManager();
      this.webrtcManager = new window.WebRTCManager();
      
      // Make dashboard and webrtc available globally
      window.dashboardManager = this.dashboardManager;
      window.webrtcManager = this.webrtcManager;
      
      // Wait for auth state to be determined
      await this.waitForAuth();
      
    } catch (error) {
      console.error('Failed to initialize application:', error);
      this.showError('Failed to initialize application');
    }
  }
  
  async waitForAuth() {
    return new Promise((resolve) => {
      const checkAuth = () => {
        const user = this.authManager.getCurrentUser();
        
        if (user) {
          // User is authenticated, initialize dashboard
          this.initializeDashboard();
          resolve();
        } else {
          // Check if we're still loading or need to show login
          setTimeout(() => {
            if (!this.authManager.getCurrentUser()) {
              this.authManager.showLogin();
            }
            resolve();
          }, 2000);
        }
      };
      
      // Check immediately and then periodically
      checkAuth();
    });
  }
  
  async initializeDashboard() {
    try {
      // Initialize Socket.IO connection
      await this.initializeSocket();
      
      // Initialize dashboard with socket and webrtc
      this.dashboardManager.initialize(this.socket, this.webrtcManager);
      
      // Load initial devices
      await this.dashboardManager.loadDevices();
      
      // Show main dashboard
      this.authManager.showDashboard();
      
    } catch (error) {
      console.error('Failed to initialize dashboard:', error);
      this.authManager.showError('Failed to connect to server');
    }
  }
  
  async initializeSocket() {
    return new Promise((resolve, reject) => {
      try {
        // Create Socket.IO connection
        this.socket = io(window.AppConfig.websocketUrl, {
          transports: ['websocket', 'polling'],
          upgrade: true,
          rememberUpgrade: true,
          timeout: 10000
        });
        
        // Handle connection
        this.socket.on('connect', async () => {
          console.log('Socket connected:', this.socket.id);
          
          try {
            // Authenticate with server
            const idToken = await this.authManager.getCurrentIdToken();
            if (idToken) {
              this.socket.emit('admin-auth', { idToken });
            }
            
            resolve();
            
          } catch (error) {
            console.error('Authentication failed:', error);
            reject(error);
          }
        });
        
        // Handle connection errors
        this.socket.on('connect_error', (error) => {
          console.error('Socket connection error:', error);
          reject(error);
        });
        
        // Handle authentication responses
        this.socket.on('auth-success', (data) => {
          console.log('Admin authenticated:', data.user);
        });
        
        this.socket.on('auth-error', (data) => {
          console.error('Admin authentication failed:', data.error);
          this.authManager.showError('Authentication failed');
        });
        
        // Set connection timeout
        setTimeout(() => {
          if (!this.socket.connected) {
            reject(new Error('Connection timeout'));
          }
        }, 10000);
        
      } catch (error) {
        reject(error);
      }
    });
  }
  
  showLoading() {
    document.getElementById('loadingScreen').classList.remove('hidden');
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('mainDashboard').classList.add('hidden');
  }
  
  showError(message) {
    console.error(message);
    // You can implement a more sophisticated error display here
    alert(message);
  }
  
  // Cleanup method for page unload
  cleanup() {
    if (this.socket) {
      this.socket.disconnect();
    }
    
    if (this.webrtcManager) {
      this.webrtcManager.cleanup();
    }
    
    if (this.dashboardManager) {
      this.dashboardManager.disconnect();
    }
  }
}

// Utility functions
function showToast(message, type = 'info') {
  // Create toast container if it doesn't exist
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  
  // Create toast element
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-header">
      <span class="toast-title">${type.charAt(0).toUpperCase() + type.slice(1)}</span>
      <button class="toast-close">&times;</button>
    </div>
    <div class="toast-message">${message}</div>
  `;
  
  // Add to container
  container.appendChild(toast);
  
  // Add close functionality
  const closeBtn = toast.querySelector('.toast-close');
  closeBtn.addEventListener('click', () => {
    toast.remove();
  });
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    if (toast.parentNode) {
      toast.remove();
    }
  }, 5000);
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  console.log('Child Monitor Admin Dashboard - Initializing...');
  
  // Create global app instance
  window.childMonitorApp = new ChildMonitorApp();
  
  // Global error handler
  window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    showToast('An unexpected error occurred', 'error');
  });
  
  // Handle page unload
  window.addEventListener('beforeunload', () => {
    if (window.childMonitorApp) {
      window.childMonitorApp.cleanup();
    }
  });
  
  // Handle visibility change (tab switching)
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      console.log('Page hidden - pausing activities');
    } else {
      console.log('Page visible - resuming activities');
      
      // Refresh devices list when page becomes visible
      if (window.dashboardManager) {
        window.dashboardManager.loadDevices();
      }
    }
  });
});

// Export for debugging
window.showToast = showToast;