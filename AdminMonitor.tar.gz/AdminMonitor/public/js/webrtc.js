class WebRTCManager {
  constructor() {
    this.peerConnection = null;
    this.localStream = null;
    this.remoteStream = null;
    this.isConnected = false;
    this.currentDevice = null;
    
    this.remoteVideo = document.getElementById('remoteVideo');
    this.videoOverlay = document.getElementById('videoOverlay');
    this.connectingMessage = document.getElementById('connectingMessage');
    this.streamingMessage = document.getElementById('streamingMessage');
    this.noDeviceMessage = document.getElementById('noDeviceMessage');
    
    this.initializeElements();
  }
  
  initializeElements() {
    // Video quality monitoring
    this.videoQuality = document.getElementById('videoQuality');
    this.streamStatus = document.getElementById('streamStatus');
    this.currentDeviceSpan = document.getElementById('currentDevice');
    
    // Monitor video metadata
    this.remoteVideo.addEventListener('loadedmetadata', () => {
      this.updateVideoQuality();
    });
    
    this.remoteVideo.addEventListener('resize', () => {
      this.updateVideoQuality();
    });
  }
  
  async createPeerConnection() {
    try {
      // Get TURN server configuration
      const turnConfig = await this.getTurnConfiguration();
      
      const configuration = {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          ...turnConfig
        ],
        iceCandidatePoolSize: 10
      };
      
      this.peerConnection = new RTCPeerConnection(configuration);
      
      // Set up event handlers
      this.peerConnection.onicecandidate = (event) => {
        if (event.candidate && window.dashboardManager) {
          window.dashboardManager.sendIceCandidate(event.candidate);
        }
      };
      
      this.peerConnection.ontrack = (event) => {
        console.log('Received remote stream');
        this.remoteStream = event.streams[0];
        this.remoteVideo.srcObject = this.remoteStream;
        this.showStreamingState();
        this.updateVideoQuality();
      };
      
      this.peerConnection.oniceconnectionstatechange = () => {
        const state = this.peerConnection.iceConnectionState;
        console.log('ICE connection state:', state);
        this.updateConnectionState(state);
      };
      
      this.peerConnection.onsignalingstatechange = () => {
        console.log('Signaling state:', this.peerConnection.signalingState);
      };
      
      this.peerConnection.onicegatheringstatechange = () => {
        console.log('ICE gathering state:', this.peerConnection.iceGatheringState);
      };
      
      return this.peerConnection;
      
    } catch (error) {
      console.error('Failed to create peer connection:', error);
      throw error;
    }
  }
  
  async getTurnConfiguration() {
    try {
      const response = await fetch('/turn-credentials');
      const credentials = await response.json();
      
      return credentials.urls.map(url => {
        if (url.startsWith('turn:') || url.startsWith('turns:')) {
          return {
            urls: url,
            username: credentials.username,
            credential: credentials.credential
          };
        } else {
          return { urls: url };
        }
      });
      
    } catch (error) {
      console.error('Failed to get TURN configuration:', error);
      return [];
    }
  }
  
  async requestStream(deviceId) {
    try {
      this.currentDevice = deviceId;
      this.currentDeviceSpan.textContent = deviceId;
      this.showConnectingState();
      
      // Create peer connection if not exists
      if (!this.peerConnection) {
        await this.createPeerConnection();
      }
      
      // Request stream from device via socket
      if (window.dashboardManager) {
        window.dashboardManager.requestDeviceStream(deviceId);
      }
      
    } catch (error) {
      console.error('Failed to request stream:', error);
      this.showError('Failed to request stream from device');
    }
  }
  
  async handleOffer(offer, fromDeviceId) {
    try {
      console.log('Handling offer from device:', fromDeviceId);
      
      if (!this.peerConnection) {
        await this.createPeerConnection();
      }
      
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
      
      const answer = await this.peerConnection.createAnswer();
      await this.peerConnection.setLocalDescription(answer);
      
      // Send answer back via socket
      if (window.dashboardManager) {
        window.dashboardManager.sendAnswer(answer, fromDeviceId);
      }
      
    } catch (error) {
      console.error('Failed to handle offer:', error);
      this.showError('Failed to establish connection');
    }
  }
  
  async handleAnswer(answer) {
    try {
      console.log('Handling answer from device');
      
      if (this.peerConnection) {
        await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
      }
      
    } catch (error) {
      console.error('Failed to handle answer:', error);
    }
  }
  
  async handleIceCandidate(candidate) {
    try {
      if (this.peerConnection) {
        await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
      }
      
    } catch (error) {
      console.error('Failed to handle ICE candidate:', error);
    }
  }
  
  updateConnectionState(state) {
    this.streamStatus.textContent = state;
    
    switch (state) {
      case 'connected':
      case 'completed':
        this.isConnected = true;
        this.streamStatus.className = 'status-online';
        break;
        
      case 'disconnected':
      case 'failed':
      case 'closed':
        this.isConnected = false;
        this.streamStatus.className = 'status-offline';
        this.showNoDeviceState();
        break;
        
      case 'connecting':
      case 'checking':
        this.isConnected = false;
        this.streamStatus.className = 'status-connecting';
        this.showConnectingState();
        break;
        
      default:
        this.isConnected = false;
        this.streamStatus.className = '';
    }
  }
  
  updateVideoQuality() {
    if (this.remoteVideo.videoWidth && this.remoteVideo.videoHeight) {
      const quality = `${this.remoteVideo.videoWidth}x${this.remoteVideo.videoHeight}`;
      this.videoQuality.textContent = quality;
    } else {
      this.videoQuality.textContent = '-';
    }
  }
  
  stopStream() {
    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }
    
    if (this.remoteStream) {
      this.remoteStream.getTracks().forEach(track => track.stop());
      this.remoteStream = null;
    }
    
    this.remoteVideo.srcObject = null;
    this.currentDevice = null;
    this.isConnected = false;
    
    this.currentDeviceSpan.textContent = 'None selected';
    this.videoQuality.textContent = '-';
    this.streamStatus.textContent = 'Disconnected';
    this.streamStatus.className = 'status-offline';
    
    this.showNoDeviceState();
    
    // Notify dashboard
    if (window.dashboardManager) {
      window.dashboardManager.notifyStreamStopped();
    }
  }
  
  showConnectingState() {
    this.videoOverlay.classList.remove('hidden');
    this.noDeviceMessage.classList.add('hidden');
    this.streamingMessage.classList.add('hidden');
    this.connectingMessage.classList.remove('hidden');
  }
  
  showStreamingState() {
    this.videoOverlay.classList.remove('hidden');
    this.noDeviceMessage.classList.add('hidden');
    this.connectingMessage.classList.add('hidden');
    this.streamingMessage.classList.remove('hidden');
    
    // Hide overlay after 3 seconds to show video
    setTimeout(() => {
      this.videoOverlay.classList.add('hidden');
    }, 3000);
  }
  
  showNoDeviceState() {
    this.videoOverlay.classList.remove('hidden');
    this.connectingMessage.classList.add('hidden');
    this.streamingMessage.classList.add('hidden');
    this.noDeviceMessage.classList.remove('hidden');
  }
  
  showError(message) {
    console.error(message);
    this.showNoDeviceState();
    
    // Show error in overlay
    this.noDeviceMessage.innerHTML = `
      <h3>Connection Error</h3>
      <p>${message}</p>
      <p>Please try again or select another device</p>
    `;
  }
  
  getConnectionStats() {
    if (!this.peerConnection) return null;
    
    return this.peerConnection.getStats().then(stats => {
      const result = {};
      stats.forEach(report => {
        if (report.type === 'inbound-rtp' && report.mediaType === 'video') {
          result.bytesReceived = report.bytesReceived;
          result.packetsReceived = report.packetsReceived;
          result.packetsLost = report.packetsLost;
          result.frameWidth = report.frameWidth;
          result.frameHeight = report.frameHeight;
          result.framesPerSecond = report.framesPerSecond;
        }
      });
      return result;
    });
  }
  
  // Method to periodically check connection health
  startHealthCheck() {
    this.healthCheckInterval = setInterval(async () => {
      if (this.isConnected && this.peerConnection) {
        try {
          const stats = await this.getConnectionStats();
          if (stats) {
            // Update UI with connection stats if needed
            console.log('Connection stats:', stats);
          }
        } catch (error) {
          console.error('Health check failed:', error);
        }
      }
    }, 5000); // Check every 5 seconds
  }
  
  stopHealthCheck() {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }
  
  cleanup() {
    this.stopStream();
    this.stopHealthCheck();
  }
}

// Export for global use
window.WebRTCManager = WebRTCManager;