# Child Monitor Admin Dashboard

Production-ready admin dashboard dengan Firebase integration untuk monitoring realtime camera dari aplikasi Child Monitor Android.

## 🔧 Setup & Configuration

### 1. Firebase Configuration
File konfigurasi Firebase sudah disetup menggunakan project `ikky-b414a`:

- **Project ID**: `ikky-b414a`
- **Service Account**: `/config/serviceAccountKey.json`
- **Web Config**: Sudah di-update di `public/js/config.js`

### 2. Environment Variables
File `.env` sudah dikonfigurasi dengan:

```env
PORT=3000
NODE_ENV=production
SERVER_IP=34.143.198.169
DOMAIN=child.finnsyde.lol
FIREBASE_PROJECT_ID=ikky-b414a
# ... Firebase credentials
```

## 📂 Project Structure

```
AdminMonitor/
├── src/
│   ├── server.js                 # Main Express server
│   ├── services/
│   │   ├── FirebaseService.js    # Firebase Admin SDK integration
│   │   ├── DeviceManager.js      # Device registration & management
│   │   └── WebRTCSignaling.js    # WebRTC signaling server
│   └── utils/
│       └── Logger.js             # Advanced logging system
├── public/                       # Web dashboard frontend
│   ├── index.html               # Main dashboard UI
│   ├── js/
│   │   ├── config.js            # Firebase & app configuration
│   │   ├── auth.js              # Google authentication
│   │   ├── webrtc.js            # WebRTC client logic
│   │   ├── dashboard.js         # Dashboard management
│   │   └── app.js               # Main application logic
│   └── css/                     # Styling files
├── config/
│   └── serviceAccountKey.json   # Firebase service account
├── logs/                        # Server logs (auto-generated)
└── package.json                 # Dependencies & scripts
```

## 🚀 Installation & Deployment

### 1. Local Development
```bash
cd AdminMonitor
npm install
npm run dev    # Development mode with nodemon
```

### 2. Production Deployment
```bash
# Upload to server
tar -czf AdminMonitor.tar.gz AdminMonitor/
scp AdminMonitor.tar.gz user@34.143.198.169:~/

# Extract & setup on server
ssh user@34.143.198.169
tar -xzf AdminMonitor.tar.gz
cd AdminMonitor
npm install --production
npm start
```

### 3. PM2 Process Management
```bash
# Install PM2
npm install -g pm2

# Start with PM2
pm2 start src/server.js --name "childmonitor-admin"
pm2 save
pm2 startup
```

## 🔧 Firebase Setup

### Firestore Collections
Server akan otomatis membuat collections:

1. **devices** - Device registration & status
2. **admins** - Admin user permissions  
3. **activity_logs** - Transparent activity logging

### Security Rules
Pastikan Firestore rules mengizinkan:
- Admin read/write access ke semua collections
- Device write access ke own document di `devices`
- Activity logs write-only untuk devices

### Authentication
- **Admin**: Google Sign-In via Firebase Auth
- **Device**: Anonymous authentication dengan user mapping

## 🌐 API Endpoints

### Health & Status
- `GET /health` - Server health check
- `GET /turn-credentials` - WebRTC TURN server credentials

### Device Management  
- `GET /api/devices` - List all registered devices
- `GET /api/devices/:deviceId` - Get specific device info

### Authentication
- `POST /api/admin/login` - Admin authentication

### WebSocket Events
- `admin-auth` - Admin authentication via ID token
- `device-register` - Device registration
- `join-room` / `leave-room` - Room management
- `offer` / `answer` / `ice-candidate` - WebRTC signaling

## 🔒 Security Features

### Server Security
- ✅ Helmet.js untuk security headers
- ✅ CORS configuration  
- ✅ Rate limiting (100 req/15min)
- ✅ Request compression
- ✅ Input validation

### Firebase Security
- ✅ Admin SDK dengan service account
- ✅ ID token verification
- ✅ Role-based access control
- ✅ Secure Firestore rules

### WebRTC Security
- ✅ STUN/TURN server authentication
- ✅ DTLS encryption untuk media
- ✅ ICE candidate filtering
- ✅ Connection state monitoring

## 📊 Monitoring & Logging

### Log Files (auto-generated)
- `logs/info.log` - General application logs
- `logs/error.log` - Error tracking
- `logs/warn.log` - Warning messages
- `logs/combined.log` - All logs combined

### Monitoring Features
- ✅ Device connection tracking
- ✅ Admin activity logging
- ✅ WebRTC connection metrics
- ✅ Health check endpoints
- ✅ Automatic log rotation

## 🎯 Usage Flow

### Admin Authentication
1. Admin opens `https://child.finnsyde.lol`
2. Click "Sign in with Google"
3. Firebase Auth verification
4. Server validates admin permissions
5. Dashboard loads with device list

### Device Connection
1. Android app registers with Firebase
2. Device appears in admin dashboard
3. Admin clicks "Request Stream"
4. WebRTC connection established
5. Live video streaming begins

### Room Management
- Each device has unique room ID
- Multiple admins can monitor same device
- Automatic cleanup on disconnect
- Connection state synchronization

## 🐛 Troubleshooting

### Firebase Issues
```bash
# Check service account permissions
# Verify Firestore rules
# Check authentication configuration
```

### WebRTC Connection Issues
```bash
# Test TURN server: https://child.finnsyde.lol/turn-credentials
# Check firewall ports: 3478, 5349, 10000-20000
# Verify ICE candidate generation
```

### Server Issues
```bash
# Check logs: pm2 logs childmonitor-admin
# Check health: curl https://child.finnsyde.lol/health
# Monitor resources: htop
```

## 🔄 Updates & Maintenance

### Updating Code
```bash
# Stop service
pm2 stop childmonitor-admin

# Update files
# ... upload new version ...

# Restart
pm2 start childmonitor-admin
```

### Database Maintenance
- Automatic log cleanup (7 days default)
- Device status health checks
- Connection timeout handling
- Firebase connection pooling

Sistem sudah production-ready dengan proper Firebase integration menggunakan project `ikky-b414a` yang sudah ada!