const { v4: uuidv4 } = require('uuid');
const Logger = require('../utils/Logger');

class DeviceManager {
  constructor(firebaseService) {
    this.firebaseService = firebaseService;
    this.logger = new Logger();
    this.activeDevices = new Map(); // socketId -> deviceInfo
    this.deviceSockets = new Map(); // deviceId -> socketId
  }
  
  async registerDevice(socketId, deviceData) {
    try {
      // Generate unique device ID if not provided
      const deviceId = deviceData.deviceId || this.generateDeviceId();
      
      const deviceInfo = {
        deviceId: deviceId,
        socketId: socketId,
        deviceName: deviceData.deviceName || `Device-${deviceId.substring(0, 8)}`,
        platform: deviceData.platform || 'Android',
        version: deviceData.version || '1.0.0',
        userId: deviceData.userId,
        roomId: `room_${deviceId}`,
        status: 'online',
        connectedAt: new Date().toISOString(),
        lastSeen: new Date().toISOString(),
        capabilities: {
          camera: true,
          audio: true,
          streaming: false
        }
      };
      
      // Store in memory
      this.activeDevices.set(socketId, deviceInfo);
      this.deviceSockets.set(deviceId, socketId);
      
      // Save to Firebase
      await this.firebaseService.saveDevice(deviceInfo);
      await this.firebaseService.logActivity(deviceId, 'Device registered');
      
      this.logger.info(`Device registered: ${deviceId} (${socketId})`);
      return deviceInfo;
      
    } catch (error) {
      this.logger.error('Device registration failed:', error);
      throw error;
    }
  }
  
  async getDevice(deviceId) {
    try {
      // First check memory
      const socketId = this.deviceSockets.get(deviceId);
      if (socketId && this.activeDevices.has(socketId)) {
        return this.activeDevices.get(socketId);
      }
      
      // Fallback to Firebase
      return await this.firebaseService.getDevice(deviceId);
      
    } catch (error) {
      this.logger.error('Failed to get device:', error);
      throw error;
    }
  }
  
  async getAllDevices() {
    try {
      // Get from Firebase for complete list
      const firebaseDevices = await this.firebaseService.getAllDevices();
      
      // Merge with active devices status
      const devices = firebaseDevices.map(device => {
        const socketId = this.deviceSockets.get(device.deviceId);
        const isActive = socketId && this.activeDevices.has(socketId);
        
        return {
          ...device,
          isOnline: isActive,
          lastSeen: isActive ? new Date().toISOString() : device.lastSeen
        };
      });
      
      return devices;
      
    } catch (error) {
      this.logger.error('Failed to get all devices:', error);
      throw error;
    }
  }
  
  async updateDeviceStatus(deviceId, status, additionalData = {}) {
    try {
      const socketId = this.deviceSockets.get(deviceId);
      
      if (socketId && this.activeDevices.has(socketId)) {
        const deviceInfo = this.activeDevices.get(socketId);
        deviceInfo.status = status;
        deviceInfo.lastSeen = new Date().toISOString();
        
        // Update capabilities if provided
        if (additionalData.capabilities) {
          deviceInfo.capabilities = { ...deviceInfo.capabilities, ...additionalData.capabilities };
        }
        
        this.activeDevices.set(socketId, deviceInfo);
      }
      
      // Update in Firebase
      await this.firebaseService.updateDeviceStatus(deviceId, status);
      await this.firebaseService.logActivity(deviceId, `Status changed to ${status}`);
      
      this.logger.info(`Device status updated: ${deviceId} - ${status}`);
      
    } catch (error) {
      this.logger.error('Failed to update device status:', error);
      throw error;
    }
  }
  
  async setDeviceStreaming(deviceId, streaming) {
    try {
      await this.updateDeviceStatus(deviceId, streaming ? 'streaming' : 'online', {
        capabilities: { streaming: streaming }
      });
      
      await this.firebaseService.logActivity(deviceId, 
        streaming ? 'Started streaming' : 'Stopped streaming'
      );
      
    } catch (error) {
      this.logger.error('Failed to set device streaming status:', error);
      throw error;
    }
  }
  
  setDeviceOffline(deviceId) {
    try {
      const socketId = this.deviceSockets.get(deviceId);
      
      if (socketId) {
        this.activeDevices.delete(socketId);
        this.deviceSockets.delete(deviceId);
      }
      
      // Update Firebase (don't await to avoid blocking)
      this.firebaseService.updateDeviceStatus(deviceId, 'offline')
        .catch(error => this.logger.error('Failed to update offline status:', error));
      
      this.firebaseService.logActivity(deviceId, 'Device disconnected')
        .catch(error => this.logger.error('Failed to log offline activity:', error));
      
      this.logger.info(`Device set offline: ${deviceId}`);
      
    } catch (error) {
      this.logger.error('Failed to set device offline:', error);
    }
  }
  
  getActiveDeviceCount() {
    return this.activeDevices.size;
  }
  
  getDeviceBySocketId(socketId) {
    return this.activeDevices.get(socketId);
  }
  
  getSocketIdByDeviceId(deviceId) {
    return this.deviceSockets.get(deviceId);
  }
  
  generateDeviceId() {
    return `device_${uuidv4().replace(/-/g, '').substring(0, 16)}`;
  }
  
  async getDeviceActivityLogs(deviceId, limit = 50) {
    try {
      return await this.firebaseService.getActivityLogs(deviceId, limit);
    } catch (error) {
      this.logger.error('Failed to get device activity logs:', error);
      throw error;
    }
  }
  
  // Health check for devices
  async performHealthCheck() {
    try {
      const offlineDevices = [];
      
      for (const [socketId, deviceInfo] of this.activeDevices) {
        const timeSinceLastSeen = Date.now() - new Date(deviceInfo.lastSeen).getTime();
        
        // If device hasn't been seen for more than 5 minutes, mark as offline
        if (timeSinceLastSeen > 5 * 60 * 1000) {
          offlineDevices.push(deviceInfo.deviceId);
        }
      }
      
      // Clean up offline devices
      for (const deviceId of offlineDevices) {
        this.setDeviceOffline(deviceId);
      }
      
      this.logger.info(`Health check completed. Cleaned up ${offlineDevices.length} offline devices`);
      
    } catch (error) {
      this.logger.error('Health check failed:', error);
    }
  }
}

module.exports = DeviceManager;