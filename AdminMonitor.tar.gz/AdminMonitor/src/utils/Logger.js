const fs = require('fs');
const path = require('path');

class Logger {
  constructor() {
    this.logDir = path.join(__dirname, '../../logs');
    this.ensureLogDirectory();
  }
  
  ensureLogDirectory() {
    if (!fs.existsSync(this.logDir)) {
      fs.mkdirSync(this.logDir, { recursive: true });
    }
  }
  
  getTimestamp() {
    return new Date().toISOString();
  }
  
  formatMessage(level, message, data = null) {
    const timestamp = this.getTimestamp();
    let logMessage = `[${timestamp}] [${level.toUpperCase()}] ${message}`;
    
    if (data) {
      if (typeof data === 'object') {
        logMessage += '\n' + JSON.stringify(data, null, 2);
      } else {
        logMessage += ' ' + data;
      }
    }
    
    return logMessage;
  }
  
  writeToFile(level, message) {
    const logFile = path.join(this.logDir, `${level}.log`);
    const combinedLogFile = path.join(this.logDir, 'combined.log');
    
    try {
      // Write to level-specific log file
      fs.appendFileSync(logFile, message + '\n');
      
      // Write to combined log file
      fs.appendFileSync(combinedLogFile, message + '\n');
      
    } catch (error) {
      console.error('Failed to write to log file:', error);
    }
  }
  
  info(message, data = null) {
    const formattedMessage = this.formatMessage('info', message, data);
    console.log('\x1b[36m%s\x1b[0m', formattedMessage); // Cyan
    this.writeToFile('info', formattedMessage);
  }
  
  error(message, error = null) {
    let errorData = null;
    
    if (error instanceof Error) {
      errorData = {
        message: error.message,
        stack: error.stack,
        name: error.name
      };
    } else if (error) {
      errorData = error;
    }
    
    const formattedMessage = this.formatMessage('error', message, errorData);
    console.error('\x1b[31m%s\x1b[0m', formattedMessage); // Red
    this.writeToFile('error', formattedMessage);
  }
  
  warn(message, data = null) {
    const formattedMessage = this.formatMessage('warn', message, data);
    console.warn('\x1b[33m%s\x1b[0m', formattedMessage); // Yellow
    this.writeToFile('warn', formattedMessage);
  }
  
  debug(message, data = null) {
    if (process.env.NODE_ENV === 'development') {
      const formattedMessage = this.formatMessage('debug', message, data);
      console.debug('\x1b[90m%s\x1b[0m', formattedMessage); // Gray
      this.writeToFile('debug', formattedMessage);
    }
  }
  
  // Method to clean old log files
  cleanOldLogs(daysToKeep = 7) {
    try {
      const files = fs.readdirSync(this.logDir);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);
      
      files.forEach(file => {
        const filePath = path.join(this.logDir, file);
        const stats = fs.statSync(filePath);
        
        if (stats.mtime < cutoffDate) {
          fs.unlinkSync(filePath);
          this.info(`Cleaned old log file: ${file}`);
        }
      });
      
    } catch (error) {
      this.error('Failed to clean old logs:', error);
    }
  }
  
  // Method to get recent logs
  getRecentLogs(level = 'combined', lines = 100) {
    try {
      const logFile = path.join(this.logDir, `${level}.log`);
      
      if (!fs.existsSync(logFile)) {
        return [];
      }
      
      const content = fs.readFileSync(logFile, 'utf8');
      const logLines = content.trim().split('\n');
      
      return logLines.slice(-lines).reverse();
      
    } catch (error) {
      this.error('Failed to get recent logs:', error);
      return [];
    }
  }
}

module.exports = Logger;