const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const compression = require('compression');
const path = require('path');
require('dotenv').config();

const FirebaseService = require('./services/FirebaseService');
const DeviceManager = require('./services/DeviceManager');
const WebRTCSignaling = require('./services/WebRTCSignaling');
const Logger = require('./utils/Logger');

class AdminServer {
  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.io = socketIo(this.server, {
      cors: {
        origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
        methods: ["GET", "POST"],
        credentials: true
      }
    });
    
    this.firebaseService = new FirebaseService();
    this.deviceManager = new DeviceManager(this.firebaseService);
    this.webrtcSignaling = new WebRTCSignaling(this.io, this.deviceManager);
    this.logger = new Logger();
    
    this.initializeMiddleware();
    this.initializeRoutes();
    this.initializeSocketHandlers();
  }
  
  initializeMiddleware() {
    // Security middleware
    this.app.use(helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: [
            "'self'", 
            "'unsafe-inline'", 
            "https://www.gstatic.com",
            "https://apis.google.com",
            "https://accounts.google.com"
          ],
          connectSrc: [
            "'self'", 
            "wss:", 
            "https:",
            "https://identitytoolkit.googleapis.com",
            "https://securetoken.googleapis.com",
            "https://firestore.googleapis.com"
          ],
          imgSrc: ["'self'", "data:", "https:"],
          fontSrc: ["'self'", "https://fonts.gstatic.com"],
          frameSrc: ["https://accounts.google.com"]
        }
      }
    }));
    
    this.app.use(compression());
    this.app.use(morgan('combined'));
    
    // CORS
    this.app.use(cors({
      origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
      credentials: true
    }));
    
    // Rate limiting
    const limiter = rateLimit({
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 100,
      message: 'Too many requests from this IP'
    });
    this.app.use('/api/', limiter);
    
    this.app.use(express.json({ limit: '10mb' }));
    
    // Serve static files with correct MIME types
    this.app.use(express.static(path.join(__dirname, '../public'), {
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('.js')) {
          res.setHeader('Content-Type', 'application/javascript');
        } else if (filePath.endsWith('.css')) {
          res.setHeader('Content-Type', 'text/css');
        } else if (filePath.endsWith('.html')) {
          res.setHeader('Content-Type', 'text/html');
        }
      }
    }));
  }
  
  initializeRoutes() {
    // Health check
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        activeDevices: this.deviceManager.getActiveDeviceCount(),
        activeConnections: this.io.engine.clientsCount
      });
    });
    
    // TURN server credentials
    this.app.get('/turn-credentials', (req, res) => {
      res.json({
        urls: [
          `stun:${process.env.SERVER_IP}:3478`,
          `turn:${process.env.SERVER_IP}:3478`,
          `turns:${process.env.DOMAIN}:5349`
        ],
        username: 'childmonitor',
        credential: 'childmonitor123'
      });
    });
    
    // API Routes
    this.app.get('/api/devices', async (req, res) => {
      try {
        const devices = await this.deviceManager.getAllDevices();
        res.json(devices);
      } catch (error) {
        this.logger.error('Failed to get devices:', error);
        res.status(500).json({ error: 'Failed to fetch devices' });
      }
    });
    
    this.app.get('/api/devices/:deviceId', async (req, res) => {
      try {
        const device = await this.deviceManager.getDevice(req.params.deviceId);
        if (!device) {
          return res.status(404).json({ error: 'Device not found' });
        }
        res.json(device);
      } catch (error) {
        this.logger.error('Failed to get device:', error);
        res.status(500).json({ error: 'Failed to fetch device' });
      }
    });
    
    this.app.post('/api/admin/login', async (req, res) => {
      try {
        const { idToken } = req.body;
        const adminUser = await this.firebaseService.verifyAdminToken(idToken);
        res.json({ success: true, user: adminUser });
      } catch (error) {
        this.logger.error('Admin login failed:', error);
        res.status(401).json({ error: 'Authentication failed' });
      }
    });
    
    // Serve admin dashboard
    this.app.get('/', (req, res) => {
      res.sendFile(path.join(__dirname, '../public/index.html'));
    });
    
    // 404 handler
    this.app.use('*', (req, res) => {
      res.status(404).json({ error: 'Route not found' });
    });
    
    // Error handler
    this.app.use((error, req, res, next) => {
      this.logger.error('Server error:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
  }
  
  initializeSocketHandlers() {
    this.io.on('connection', (socket) => {
      this.logger.info(`New client connected: ${socket.id}`);
      
      // Handle admin authentication
      socket.on('admin-auth', async (data) => {
        try {
          const adminUser = await this.firebaseService.verifyAdminToken(data.idToken);
          socket.adminUser = adminUser;
          socket.join('admin-room');
          socket.emit('auth-success', { user: adminUser });
          this.logger.info(`Admin authenticated: ${adminUser.email}`);
        } catch (error) {
          socket.emit('auth-error', { error: 'Authentication failed' });
          this.logger.error('Admin auth failed:', error);
        }
      });
      
      // Handle device registration
      socket.on('device-register', async (data) => {
        try {
          const device = await this.deviceManager.registerDevice(socket.id, data);
          socket.deviceId = device.deviceId;
          socket.emit('device-registered', device);
          
          // Notify admins
          socket.to('admin-room').emit('device-online', device);
          this.logger.info(`Device registered: ${device.deviceId}`);
        } catch (error) {
          socket.emit('registration-error', { error: 'Registration failed' });
          this.logger.error('Device registration failed:', error);
        }
      });
      
      // WebRTC signaling
      this.webrtcSignaling.handleConnection(socket);
      
      // Handle disconnect
      socket.on('disconnect', () => {
        this.logger.info(`Client disconnected: ${socket.id}`);
        
        if (socket.deviceId) {
          this.deviceManager.setDeviceOffline(socket.deviceId);
          socket.to('admin-room').emit('device-offline', { deviceId: socket.deviceId });
        }
      });
    });
  }
  
  start() {
    const PORT = process.env.PORT || 3000;
    
    this.server.listen(PORT, () => {
      this.logger.info(`Child Monitor Admin Server running on port ${PORT}`);
      this.logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
    });
    
    // Graceful shutdown
    process.on('SIGTERM', () => {
      this.logger.info('SIGTERM received, shutting down gracefully');
      this.server.close(() => {
        this.logger.info('Process terminated');
        process.exit(0);
      });
    });
  }
}

// Start server
const adminServer = new AdminServer();
adminServer.start();